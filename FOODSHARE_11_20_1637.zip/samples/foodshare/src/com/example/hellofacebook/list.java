package com.example.hellofacebook;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by JSR on 2015-11-18.
 */
public class list extends Activity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
