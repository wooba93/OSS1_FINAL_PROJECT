package com.example.hellofacebook;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaActionSound;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.Arrays;

import com.facebook.Profile;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * Created by josungryong on 2015-11-10.
 */
public class write extends Activity implements Spinner.OnItemSelectedListener {

    private Profile profile = Profile.getCurrentProfile(); // 작성자 정보

    // 카메라 관련 변수
    private static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 100;
    private Uri fileUri; // 이미지 파일 리턴 값 저장
    public static final int MEDIA_TYPE_IMAGE = 1;
    private ImageView picture;
    private Button takepicutre;

    //////////////////////////////////////////////////////////////////////////////

    String[] foodstyle = {"전체", "한식", "중식", "양식", "일식"};
    String[] area = {"전체", "서울", "경기"};
    String foodstyleInpo=""; String areaInpo=""; // 선택에 따른  값 저장 서버로 보낼 것
    EditText text_foodname = null;
    String foodname = "";
    EditText text_price = null;
    String price="";
    EditText text_location = null;
    String location="";
    EditText text_comment = null;
    String comment="";
    static String pictureName = "";
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.write);

        // 카메라
        picture = (ImageView) findViewById(R.id.picture);
        takepicutre = (Button) findViewById(R.id.takepicture);

        // 스트링
        text_foodname = (EditText) findViewById(R.id.foodname);
        text_price = (EditText) findViewById(R.id.price);
        text_location = (EditText) findViewById(R.id.location);
        text_comment = (EditText) findViewById(R.id.comment);

        // 스피너
        Spinner foodstyleButton = (Spinner) findViewById(R.id.foodstyle);
        foodstyleButton.setOnItemSelectedListener(this); // 스피너에 아이템 클릭 시 실행될 리스너 foodstyle
        Spinner areaButton = (Spinner) findViewById(R.id.area);
        areaButton.setOnItemSelectedListener(this); // 스피너에 아이템 클릭 시 실행될 리스너 legion


         /* 어댑터 배열 객체 생성(this는 Context 메인 액티비티를 가리킴,
         * 안드로이드에 있는 어댑터 객체 에서 지원해주는 스피너 레이아웃,아이템 배열)
         * android는 안드로이드가 가지고 있는 전역 변수*/
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, foodstyle);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 리스트 형태로 늘림
        foodstyleButton.setAdapter(adapter); // 어댑터 설정

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, area);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 리스트 형태로 늘림
        areaButton.setAdapter(adapter3); // 어댑터 설정
    }

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch(parent.getId()) {
            case R.id.foodstyle:
                foodstyleInpo = foodstyle[position];
                break;
            case R.id.area:
                areaInpo = area[position];
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        switch (parent.getId()) {
            case R.id.foodstyle:
                foodstyleInpo = foodstyle[0];
                break;
            case R.id.area:
                areaInpo = area[0];
                break;
        }
    }


    /////////////////////// 카메라 ///////////////////////
    public void takepicture(View v) { //버튼 부
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE); // create a file to save the image
        //intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri); // set the image file name , 경로에 이미지 저장하기 떄문에 리턴값 필요없음
        //File file = new File(Environment.DIRECTORY_PICTURES + "/FoodShare", "IMG"+(new SimpleDateFormat("yyyy-mm-dd-hh:mm:ss").format(new Date())));
        //fileUri = Uri.fromFile(file);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
        startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE); // start the image capture Intent
        if (fileUri != null) {
            //camera.setVisibility(View.INVISIBLE);
        }
    }

    private int getLastImageId()
    {
        final String[] imageColumns = { MediaStore.Images.Media._ID, MediaStore.Images.Media.DATA };
        final String imageOrderBy = MediaStore.Images.Media._ID + " DESC";
        Cursor imageCursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imageColumns, null, null, imageOrderBy);
        if(imageCursor.moveToFirst())
        {
            int id = imageCursor.getInt(imageCursor.getColumnIndex(MediaStore.Images.Media._ID));
            String fullPath = imageCursor.getString(imageCursor.getColumnIndex(MediaStore.Images.Media.DATA));
            imageCursor.close();
            return id;
        }
        else
            return 0;
    }
    private void removeImage(int id)
    {
        ContentResolver cr = getContentResolver();
        cr.delete(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, MediaStore.Images.Media._ID + "=?", new String[]{ Long.toString(id) });
    }
    /**
     * Create a file Uri for saving an image or video
     */
    private static Uri getOutputMediaFileUri(int type) {
        return Uri.fromFile(getOutputMediaFile(type));
    }

    private static File getOutputMediaFile(int type) {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "FoodShare");
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("FoodShare", "failed to create directory");
                return null;
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
                    "IMG_" + timeStamp + ".jpg");
            pictureName = mediaFile.getPath();
        } else {
            return null;
        }

        return mediaFile;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Log.e("com", "result_ok");
                // Image captured and saved to fileUri specified in the Intent

                // 이미지뷰로 바로 출력
                if (data != null) {
                    picture.setImageURI(data.getData());

                    removeImage(getLastImageId());
                    //takepicutre.setVisibility(View.INVISIBLE);
                } else {
                    //takepicutre.setVisibility(View.VISIBLE);
                    Log.e("onActivityResult", fileUri.getPath());
                }
            } else if (resultCode == RESULT_CANCELED) {
                Log.e("com", "result_canceled");
                //takepicutre.setVisibility(View.VISIBLE);
                // User cancelled the image capture
            } else {
                //takepicutre.setVisibility(View.VISIBLE);
                // Image capture failed, advise user
            }
        }
    }


    /////////////////////// 카메라 ///////////////////////

    //취소 버튼//
    public void cancleButton(View v) {
        finish();
    }

    //전송 버튼//
    public void writeButton(View v) {

        foodname = text_foodname.getText().toString();
        price = text_price.getText().toString();
        location = text_location.getText().toString();
        comment = text_comment.getText().toString();
        String data = "";
        Date now = new Date();
        String dateStr = new SimpleDateFormat("yyyy-MM-dd-hh:mm:ss").format(now);

        if( !foodname.equals("") && !foodstyleInpo.equals("전체") && !areaInpo.equals("전체") && !price.equals("") || !location.equals("") || !comment.equals("") ) {

            try {
                //data.(foodstyleInpo); // + "/" + foodstyleDetailInpo + "/" + areaInpo);
                //out.writeUTF("WRITE/" + data);//.concat(data));
                GlobalSocket.out.write(("WRITE/" + dateStr + "/" + profile.getName() + "/" + foodname + "/" + foodstyleInpo + "/" + areaInpo + "/" + price + "/" + location + "/" + comment).getBytes()); // 작성자, 음식이름, 음식분류, 지역, 가격, 평가, 위치
                byte[] instrA;
                String str = "";
                String str1 = "";
                GlobalSocket.readThread.start();
                while (GlobalSocket.bBufferLength <= 0) {

                }
                instrA = new byte[GlobalSocket.bBufferLength];
                instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                str = new String(instrA, "CP949");
                GlobalSocket.bBufferLength = 0;

                GlobalSocket.out.write(("IMAGE").getBytes());
                while (GlobalSocket.bBufferLength <= 0) {

                }

                instrA = new byte[GlobalSocket.bBufferLength];
                instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                str = new String(instrA, "CP949");
                GlobalSocket.bBufferLength = 0;

                ByteArrayOutputStream baos = new ByteArrayOutputStream(1000);
                //BufferedImage img = ImageIO.read(new FILE(fileUri.getPath()));
                Bitmap img = BitmapFactory.decodeFile(pictureName);
                img.compress(Bitmap.CompressFormat.JPEG, 100, baos);

                byte[] imgByte = baos.toByteArray();

                GlobalSocket.out.writeInt(imgByte.length);
                while (GlobalSocket.bBufferLength <= 0) {

                }

                instrA = new byte[GlobalSocket.bBufferLength];
                instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                str = new String(instrA, "CP949");
                GlobalSocket.bBufferLength = 0;

                for(int i = 0; i < imgByte.length; i += 4500)
                {
                    if(imgByte.length - i >= 4500)
                        GlobalSocket.out.write(imgByte, i, 4500);
                    else
                        GlobalSocket.out.write(imgByte, i, imgByte.length - i);

                    GlobalSocket.out.flush();
                    while (GlobalSocket.bBufferLength <= 0) {

                    }

                    instrA = new byte[GlobalSocket.bBufferLength];
                    instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                    str = new String(instrA, "CP949");
                    GlobalSocket.bBufferLength = 0;
                }
                /*for(int i; (i = GlobalSocket.in.read(instrA)) != -1;)
                {
                    baos.write(instrA, 0, i);
                }
                byte[] result = baos.toByteArray();
                */
            } catch (IOException e) {
                System.out.println("bitmapErr: " + e);
            }

            finish();
            Intent intent = new Intent(write.this, list.class);
            startActivity(intent);
        }

        else {
            Toast.makeText(getApplicationContext(), "Please input data", Toast.LENGTH_SHORT).show();
        }

    }

}


