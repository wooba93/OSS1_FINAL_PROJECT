package com.example.hellofacebook;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by JSR on 2015-11-18.
 */
public class list extends Activity implements Spinner.OnItemSelectedListener {

    String[] foodstylelist2 = {"전체", "한식", "중식", "양식", "일식"};
    String[] arealist2 = {"전체", "서울", "경기"};
    String foodstyleInpo2=""; String areaInpo2="";
    static byte[] imageArr;
    ArrayList<Story> al = new ArrayList<Story>(); // 어뎁터 생성


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*if(!GlobalSocket.readThread.isAlive())
        {
            GlobalSocket.readThread.run();
        }*/

       setContentView(R.layout.list);

        ////// 리스트뷰 어뎁터 임시 ///////
        // 1. 다량의 데이터
        // 2. Adapter
        // 3. AdapterView
        /*al.add(new Story("카레덮밥","12300","서울 강서","맛없음","2015.12.07",R.drawable.icon));
        al.add(new Story("돈가스","14050","서울 강북","맛있음","2015.12.20",R.drawable.icon));*/

        // adapter
        /*MyAdapter adapter_list = new MyAdapter(
                getApplicationContext(), // 현재화면의 제어권자
                R.layout.item,
                al);

        // adapterView - ListView, GridView
        ListView lv = (ListView)findViewById(R.id.list);
        lv.setAdapter(adapter_list);*/
        ////// 리스트뷰 어뎁터 임시 끝 /////////


        // 스피너
        Spinner foodstyleListButton2 = (Spinner) findViewById(R.id.foodstylelist2);
        foodstyleListButton2.setOnItemSelectedListener(this); // 스피너에 아이템 클릭 시 실행될 리스너 foodstyle
        Spinner areaListButton2 = (Spinner) findViewById(R.id.arealist2);
        areaListButton2.setOnItemSelectedListener(this); // 스피너에 아이템 클릭 시 실행될 리스너 legion


         /* 어댑터 배열 객체 생성(this는 Context 메인 액티비티를 가리킴,
         * 안드로이드에 있는 어댑터 객체 에서 지원해주는 스피너 레이아웃,아이템 배열)
         * android는 안드로이드가 가지고 있는 전역 변수*/
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item , foodstylelist2);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 리스트 형태로 늘림
        foodstyleListButton2.setAdapter(adapter); // 어댑터 설정

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item , arealist2);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 리스트 형태로 늘림
        areaListButton2.setAdapter(adapter3); // 어댑터 설정
    }
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch(parent.getId()) {
            case R.id.foodstylelist2:
                foodstyleInpo2 = foodstylelist2[position];
                break;
            case R.id.arealist2:
                areaInpo2 = arealist2[position];
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        switch (parent.getId()) {
            case R.id.foodstylelist2:
                foodstyleInpo2 = foodstylelist2[0];
                break;
            case R.id.arealist2:
                areaInpo2 = arealist2[0];
                break;
        }
    }
    // 스피너 끝

    // 확인 버튼
    public void serchButton(View v) {

        for(int i = 0; i < al.size();) {
            al.remove(i);
        }

        MyAdapter adapter_list = new MyAdapter(
                getApplicationContext(), // 현재화면의 제어권자
                R.layout.item,
                al);

        // adapterView - ListView, GridView
        ListView lv = (ListView)findViewById(R.id.list);
        lv.setAdapter(adapter_list);

        try {
                // Ok싸인 까지
                GlobalSocket.out.write(("SEARCH/" + "foodstyleInpo" + "/" + foodstyleInpo2 + "/" + "REGION" + "/" + areaInpo2 + "/").getBytes());
                byte[] instrA;
                String str = "";
                String str1 = "";
                //GlobalSocket.readThread.start();
                while (GlobalSocket.bBufferLength <= 0) {

                }
                instrA = new byte[GlobalSocket.bBufferLength];
                instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                str = new String(instrA, "CP949");
                GlobalSocket.bBufferLength = 0;
            GlobalSocket.dataSize = 0;

            while (GlobalSocket.bBufferLength <= 0) {

            }
            instrA = new byte[GlobalSocket.bBufferLength];
            instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
            str = new String(instrA, "CP949");
            GlobalSocket.bBufferLength = 0;
            GlobalSocket.out.write("OK".getBytes());
            int strInt = Integer.parseInt(str);

            for(int i = 0; i < strInt; i ++)
            {
                while (GlobalSocket.bBufferLength <= 0) {

                }
                instrA = new byte[GlobalSocket.bBufferLength];
                instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                str = new String(instrA, "CP949");
                GlobalSocket.bBufferLength = 0;
                GlobalSocket.dataSize = 0;
                String[] data = str.split("/");
                //al.add(new Story(data[2], data[5], data[6], data[7], data[0], R.drawable.icon));

                GlobalSocket.out.write("OK".getBytes());

                while (GlobalSocket.bBufferLength <= 0) {

                }
                instrA = new byte[GlobalSocket.bBufferLength];
                instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                str = new String(instrA, "CP949");
                GlobalSocket.bBufferLength = 0;
                GlobalSocket.dataSize = 0;
                int byteLength = Integer.parseInt(str);
                imageArr = new byte[byteLength];
                int dataLength = 0;
                GlobalSocket.out.write("OK".getBytes());
                /*for(int j = 0; j < byteLength; j += dataLength)
                {
                    GlobalSocket.out.write("OK".getBytes());
                    while (GlobalSocket.bBufferLength <= 0)
                    {

                    }
                    instrA = new byte[GlobalSocket.bBufferLength];
                    instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                    dataLength = GlobalSocket.bBufferLength;
                    GlobalSocket.bBufferLength = 0;
                    System.arraycopy(instrA, 0, imageArr, j, dataLength);
                    //GlobalSocket.out.write("OK".getBytes());
                }*/
                while(GlobalSocket.dataSize < byteLength)
                {

                }
                Bitmap realimage = BitmapFactory.decodeByteArray(imageArr , 0 , imageArr.length);
                GlobalSocket.bBufferLength = 0;
                GlobalSocket.dataSize = 0;
                // 날짜 + 작성자 + 음식이름 + 종류 + 지역 + 가격 + 위치정보 + 평가 //
                al.add(new Story(data[2], data[5], data[6], data[7], data[0] + "에 " + data[1] + "님이 작성한 글 입니다.", realimage));

                GlobalSocket.out.write("OK".getBytes());
            }

            /*MyAdapter adapter_list = new MyAdapter(
                    getApplicationContext(), // 현재화면의 제어권자
                    R.layout.item,
                    al);*/

            // adapterView - ListView, GridView
            //ListView lv = (ListView)findViewById(R.id.list);
            lv.setAdapter(adapter_list);

            GlobalSocket.bBufferLength = 0;
            GlobalSocket.dataSize = 0;
        }


        catch (IOException e) {
            System.out.println("bitmapErr: " + e);
        }
    }

    public void writebutton2(View v) {
        Intent intent = new Intent(list.this, write.class);
        startActivity(intent);
    }
}


// 리스트뷰 커스텀 어댑터 //
class MyAdapter extends BaseAdapter {
    Context context;
    int layout;
    ArrayList<Story> al;
    LayoutInflater inf;
    public MyAdapter(Context context, int layout, ArrayList<Story> al) {
        this.context = context;
        this.layout = layout;
        this.al = al;
        this.inf = (LayoutInflater) context.getSystemService
                (Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() { // 총 데이터의 개수
        return al.size();
    }
    @Override
    public Object getItem(int position) { // 해당 행의 데이터
        return al.get(position);
    }
    @Override
    public long getItemId(int position) { // 해당 행의 유니크한 id
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = inf.inflate(layout, null);

        TextView tv1 = (TextView) convertView.findViewById(R.id.textView1);
        TextView tv2 = (TextView) convertView.findViewById(R.id.textView2);
        TextView tv3 = (TextView) convertView.findViewById(R.id.textView3);
        TextView tv4 = (TextView) convertView.findViewById(R.id.textView4);
        TextView tv5 = (TextView) convertView.findViewById(R.id.textView5);
        ImageView iv = (ImageView) convertView.findViewById(R.id.imageView1);


        Story s = al.get(position);
        tv1.setText(s.foodname);
        tv2.setText(s.price);
        tv3.setText(s.location);
        tv4.setText(s.comment);
        tv5.setText(s.data);
        iv.setImageBitmap(s.img);
        //iv.setImageResource(s.img);
        return convertView;
    }
}

class Story { // 자바빈
    String foodname = "";
    String price = "";
    String location = "";
    String comment = "";
    String data = "";
    Bitmap img; // 이미지
    public Story(String foodname, String price , String location, String comment , String data , Bitmap img) {
        this.foodname = foodname;
        this.price = price;
        this.location = location;
        this.comment = comment;
        this.data = data;
        this.img = img;
    }
    public Story() {} // 기본생성자 : 생성자 작업시 함께 추가하자
}